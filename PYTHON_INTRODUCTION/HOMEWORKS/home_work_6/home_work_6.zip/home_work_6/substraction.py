def substraction(x, y):
	print(f"{x} - {y} равно {int(x) - int(y)}")